/**
 * @version $Id$
 * @package DJ-ImageSlider
 * @subpackage DJ-ImageSlider Component
 * @copyright Copyright (C) 2017 DJ-Extensions.com, All rights reserved.
 * @license DJ-Extensions.com Proprietary Use License
 * @author url: http://dj-extensions.com
 * @author email contact@dj-extensions.com
 * @developer Szymon Woronowski - szymon.woronowski@design-joomla.eu
 *
 */
! function(C) {
    var t = function(r) {
        r.data();
        var d = r.data("djslider"),
            i = r.data("animation");
        r.removeAttr("data-djslider"), r.removeAttr("data-animation");
        var h = C("#djslider" + d.id).css("opacity", 0),
            u = C("#slider" + d.id).css("position", "relative"),
            s = "1" == d.css3 && function(t) {
                var i = (document.body || document.documentElement).style;
                if (void 0 === i) return !1;
                if ("string" == typeof i[t]) return t;
                v = ["Moz", "Webkit", "Khtml", "O", "ms", "Icab"], pu = t.charAt(0).toUpperCase() + t.substr(1);
                for (var n = 0; n < v.length; n++)
                    if ("string" == typeof i[v[n] + pu]) return "-" + v[n].toLowerCase() + "-" + t;
                return !1
            }("transition"),
            t = "ontouchstart" in window || 0 < navigator.MaxTouchPoints || 0 < navigator.msMaxTouchPoints,
            p = u.children("li"),
            l = d.slide_size,
            g = d.visible_slides,
            f = l * p.length,
            y = p.length - g,
            b = 0,
            n = "1" == i.auto ? 1 : 0,
            o = "1" == i.looponce ? 1 : 0,
            e = 0,
            a = !1,
            m = [];
        if (2 == d.slider_type ? (p.css("position", "absolute"), p.css("top", 0), p.css("left", 0), u.css("width", l), p.css("opacity", 0), p.css("visibility", "hidden"), C(p[0]).css("opacity", 1), C(p[0]).css("visibility", "visible"), s && p.css(s, "opacity " + i.duration + "ms " + i.css3transition)) : 1 == d.slider_type ? (u.css("top", 0), u.css("height", f), s && u.css(s, "top " + i.duration + "ms " + i.css3transition)) : (u.css(d.direction, 0), u.css("width", f), s && u.css(s, d.direction + " " + i.duration + "ms " + i.css3transition)), 0 < d.show_arrows && (C("#next" + d.id).on("click", function() {
                "right" == d.direction ? k() : x()
            }).on("keydown", function(t) {
                var i = t.which;
                13 != i && 32 != i || ("right" == d.direction ? k() : x(), t.preventDefault(), t.stopPropagation())
            }), C("#prev" + d.id).on("click", function() {
                "right" == d.direction ? x() : k()
            }).on("keydown", function(t) {
                var i = t.which;
                13 != i && 32 != i || ("right" == d.direction ? x() : k(), t.preventDefault(), t.stopPropagation())
            })), 0 < d.show_buttons && (C("#play" + d.id).on("click", function() {
                n = 1, j()
            }).on("keydown", function(t) {
                var i = t.which;
                13 != i && 32 != i || (n = 1, j(), C("#pause" + d.id).focus(), t.preventDefault(), t.stopPropagation())
            }), C("#pause" + d.id).on("click", function() {
                n = 0, j()
            }).on("keydown", function(t) {
                var i = t.which;
                13 != i && 32 != i || (n = 0, j(), C("#play" + d.id).focus(), t.preventDefault(), t.stopPropagation())
            })), r.on("mouseenter", function() {
                t || (e = 1)
            }).on("mouseleave", function() {
                r.removeClass("focused"), e = 0
            }).on("focus", function() {
                r.addClass("focused"), r.trigger("mouseenter")
            }).on("keydown", function(t) {
                var i = t.which;
                37 != i && 39 != i || (39 == i ? "right" == d.direction ? k() : x() : "right" == d.direction ? x() : k(), t.preventDefault(), t.stopPropagation())
            }), C(".djslider-end").on("focus", function() {
                r.trigger("mouseleave")
            }), r.djswipe(function(t, i) {
                i.x < 50 || 50 < i.y || ("left" == t.x ? "right" == d.direction ? k() : x() : "right" == t.x && ("right" == d.direction ? x() : k()))
            }), C("#cust-navigation" + d.id).length) {
            var c = C("#cust-navigation" + d.id).find(".load-button");
            c.each(function(n) {
                var s = C(this);
                s.on("click", function(t) {
                    a || s.hasClass("load-button-active") || I(n)
                }).on("keydown", function(t) {
                    var i = t.which;
                    13 != i && 32 != i || (a || s.hasClass("load-button-active") || I(n), t.preventDefault(), t.stopPropagation())
                }), y < n && s.css("display", "none")
            })
        }

        function w(t) {
            var i = {
                x: t.width(),
                y: t.height()
            };
            if ((0 == i.x || 0 == i.y) && t.is(":hidden")) {
                for (var n, s, o = t.parent(); o.is(":hidden");) o = (n = o).parent();
                s = o.width(), n && (s -= parseInt(n.css("margin-left")), s -= parseInt(n.css("margin-right")), s -= parseInt(n.css("border-left-width")), s -= parseInt(n.css("border-right-width")), s -= parseInt(n.css("padding-left")), s -= parseInt(n.css("padding-right")));
                var e = t.clone();
                e.css({
                    position: "absolute",
                    visibility: "hidden",
                    "max-width": s
                }), C(document.body).append(e), i = {
                    x: e.width(),
                    y: e.height()
                }, e.remove()
            }
            return i
        }

        function _() {
            var t = w(r.parent()).x,
                i = parseInt(h.css("max-width")),
                n = w(h),
                s = n.x;
            t < s ? s = t : s <= t && (!i || s < i) && (s = i < t ? i : t), m[g] || (m[g] = n.x / n.y);
            var o = m[g],
                e = s / o;
            if (h.css("width", s), h.css("height", e), 2 == d.slider_type) u.css("width", s), p.css("width", s), p.css("height", e);
            else if (1 == d.slider_type) {
                var a = parseInt(C(p[0]).css("margin-bottom"));
                l = (e + a) / g, f = p.length * l + p.length, u.css("height", f), p.css("width", s), p.css("height", l - a), u.css("top", -l * b)
            } else {
                a = "right" == d.direction ? parseInt(C(p[0]).css("margin-left")) : parseInt(C(p[0]).css("margin-right"));
                var c = Math.ceil(s / (d.slide_size + a));
                if (c != g) {
                    if (g = c > d.visible_slides ? d.visible_slides : c, y = p.length - g, C("#cust-navigation" + d.id).length) C("#cust-navigation" + d.id).find(".load-button").each(function(t) {
                        var i = C(this);
                        y < t ? i.css("display", "none") : i.css("display", "")
                    });
                    m[g] || (m[g] = (g * l - a) / n.y), e = s / (o = m[g]), h.css("height", e)
                }
                l = (s + a) / g, f = p.length * l + p.length, u.css("width", f), p.css("width", l - a), p.css("height", e), u.css(d.direction, -l * b), y < b && I(y)
            }(0 < d.show_buttons || 0 < d.show_arrows) && (button_pos = C("#navigation" + d.id).position().top, button_pos < 0 ? (r.css("padding-top", -button_pos), r.css("padding-bottom", 0)) : ((buttons_height = 0) < d.show_arrows && (buttons_height = w(C("#next" + d.id)).y, buttons_height = Math.max(buttons_height, w(C("#prev" + d.id)).y)), 0 < d.show_buttons && (buttons_height = Math.max(buttons_height, w(C("#play" + d.id)).y), buttons_height = Math.max(buttons_height, w(C("#pause" + d.id)).y)), padding = button_pos + buttons_height - e, 0 < padding ? (r.css("padding-top", 0), r.css("padding-bottom", padding)) : (r.css("padding-top", 0), r.css("padding-bottom", 0))), buttons_margin = parseInt(C("#navigation" + d.id).css("margin-left")) + parseInt(C("#navigation" + d.id).css("margin-right")), buttons_margin < 0 && w(C(window)).x < w(C("#navigation" + d.id)).x - buttons_margin && (C("#navigation" + d.id).css("margin-left", 0), C("#navigation" + d.id).css("margin-right", 0))), P()
        }

        function x() {
            b < y ? (I(b + 1), o && b == y && (n = 0, j())) : I(0)
        }

        function k() {
            I(0 < b ? b - 1 : y)
        }

        function I(t) {
            if (b != t) {
                if (2 == d.slider_type) {
                    if (a) return;
                    a = !0, prev_slide = b, b = t,
                        function(t) {
                            C(p[b]).css("visibility", "visible"), s ? (C(p[b]).css("opacity", 1), C(p[t]).css("opacity", 0)) : (C(p[b]).animate({
                                opacity: 1
                            }, i.duration, i.transition), C(p[t]).animate({
                                opacity: 0
                            }, i.duration, i.transition));
                            setTimeout(function() {
                                C(p[t]).css("visibility", "hidden"), a = !1
                            }, i.duration)
                        }(prev_slide)
                } else b = t, 1 == d.slider_type ? s ? u.css("top", -l * b) : u.animate({
                    top: -l * b
                }, i.duration, i.transition) : s ? u.css(d.direction, -l * b) : "right" == d.direction ? u.animate({
                    right: -l * b
                }, i.duration, i.transition) : u.animate({
                    left: -l * b
                }, i.duration, i.transition);
                var n;
                P(), n = b, C("#cust-navigation" + d.id).length && c.each(function(t) {
                    var i = C(this);
                    i.removeClass("load-button-active"), t == n && i.addClass("load-button-active")
                })
            }
        }

        function j() {
            n ? (C("#play" + d.id).css("display", "none"), C("#pause" + d.id).css("display", "block")) : (C("#pause" + d.id).css("display", "none"), C("#play" + d.id).css("display", "block"))
        }

        function M() {
            r.css("background", "none"), h.css("opacity", 1), 0 < d.show_buttons && (play_width = w(C("#play" + d.id)).x, C("#play" + d.id).css("margin-left", -play_width / 2), pause_width = w(C("#pause" + d.id)).x, C("#pause" + d.id).css("margin-left", -pause_width / 2), n ? C("#play" + d.id).css("display", "none") : C("#pause" + d.id).css("display", "none")),
                function t() {
                    setTimeout(function() {
                        n && !e && x(), t()
                    }, i.delay)
                }()
        }

        function P() {
            p.each(function(t) {
                var i = C(this).find("a[href], input, select, textarea, button");
                b <= t && t < b + parseInt(g) ? i.each(function() {
                    C(this).removeProp("tabindex")
                }) : i.each(function() {
                    C(this).prop("tabindex", "-1")
                })
            })
        }
        d.preload ? setTimeout(M, d.preload) : C(window).load(M), _(), C(window).on("resize", _), C(window).on("load", _)
    };
    C.fn.djswipe = C.fn.djswipe || function(t) {
        var o = !1,
            a = null,
            c = null;
        return $el = C(this), $el.on("touchstart", function(t) {
            o = !0;
            var i = t.originalEvent.changedTouches || e.originalEvent.touches;
            a = {
                x: i[0].pageX,
                y: i[0].pageY
            }
        }), $el.on("touchend", function() {
            o = !1, c && t(c.direction, c.offset), c = a = null
        }), $el.on("touchmove", function(t) {
            var i, n, s;
            o && (i = t.originalEvent.changedTouches || e.originalEvent.touches, n = i[0].pageX, s = i[0].pageY, c = {
                direction: {
                    x: n > a.x ? "right" : "left",
                    y: s > a.y ? "down" : "up"
                },
                offset: {
                    x: Math.abs(n - a.x),
                    y: Math.abs(a.y - s)
                }
            })
        }), !0
    }, C(document).ready(function() {
        C("[data-djslider]").each(function() {
            t(C(this))
        })
    })
}(jQuery);