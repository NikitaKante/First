/**
 * @version $Id$
 * @package DJ-MegaMenu
 * @copyright Copyright (C) 2017 DJ-Extensions.com, All rights reserved.
 * @license DJ-Extensions.com Proprietary Use License
 * @author url: http://dj-extensions.com
 * @author email contact@dj-extensions.com
 * @developer Szymon Woronowski - szymon.woronowski@design-joomla.eu
 */
! function(c) {
    var e = function(t, s) {
        this.options = {
            openDelay: 250,
            closeDelay: 500,
            animIn: "fadeIn",
            animOut: "fadeOut",
            animSpeed: "normal",
            duration: 450,
            wrap: null,
            direction: "ltr",
            event: "mouseenter",
            touch: "ontouchstart" in window || 0 < navigator.MaxTouchPoints || 0 < navigator.msMaxTouchPoints,
            offset: 0,
            wcag: 1
        }, this.init(t, s)
    };
    e.prototype.init = function(t, s) {
        var e = this;
        if (jQuery.extend(e.options, s), t.length) {
            switch (e.options.menu = t, e.options.blurTimer = null, e.options.animSpeed) {
                case "fast":
                    e.options.duration = 250;
                    break;
                case "slow":
                    e.options.duration = 650
            }
            t.addClass(e.options.animSpeed);
            var i = t.find("li.dj-up");
            e.kids = [], e.options.wrap = c("#" + e.options.wrap), e.options.wrap.length || (e.options.wrap = t.parents("div").last()), e.options.touch && t.on("touchstart", function(t) {
                t.stopPropagation()
            }), i.each(function(t) {
                var s = c(this);
                e.kids[t] = new o(s, 0, e, e.options)
            }), 1 == e.options.fixed && c(window).one("load", e.makeSticky.bind(e, t)), 1 == e.options.wcag && (e.focusable = t.find("a[href], [tabindex]"), t.on("keydown", function(t) {
                e.focusNearest(t)
            }))
        }
    }, e.prototype.focusNearest = function(t) {
        var i = t.which,
            o = this.options.menu.find(":focus"),
            n = o.offset(),
            a = {
                x: 1024,
                y: 1024
            },
            u = null;
        if (n) {
            this.focusable.each(function() {
                ! function(t) {
                    if (!t.is(":hidden") && t != o) {
                        var s = t.offset(),
                            e = {
                                x: Math.abs(s.left - n.left),
                                y: Math.abs(s.top - n.top)
                            };
                        37 == i && s.left < n.left || 39 == i && s.left > n.left ? (e.y < a.y || e.y == a.y && e.x < a.x) && (a = e, u = t) : (38 == i && s.top < n.top || 40 == i && s.top > n.top && e.x < t.width()) && e.x + e.y < a.x + a.y && (a = e, u = t)
                    }
                }(c(this))
            }), u && (t.preventDefault(), t.stopPropagation(), u.focus())
        }
    }, e.prototype.makeSticky = function(t) {
        var s = this;
        s.sticky = !1;
        var e = c("#" + t.attr("id") + "sticky"),
            i = c("<div />");
        i.css({
            display: "none",
            opacity: 0,
            height: t.height()
        }), i.attr("id", t.attr("id") + "placeholder"), i.insertBefore(e), c(window).scroll(s.scroll.bind(s, e, t, i, !1)), c(window).resize(s.scroll.bind(s, e, t, i, !0)), s.scroll(e, t, i, !1), c(window).on("orientationchange", function() {
            setTimeout(function() {
                c(window).trigger("resize")
            }, 500)
        })
    }, e.prototype.scroll = function(t, s, e, i) {
        var o = this;
        if (!s.is(":hidden")) {
            var n = c(window).scrollTop(),
                a = (o.sticky ? e.offset().top : s.offset().top) - parseInt(o.options.offset);
            if (o.sticky && (n < a || i) && (s.css({
                    position: "",
                    top: "",
                    background: "",
                    width: "",
                    height: ""
                }), s.removeClass("dj-megamenu-fixed"), t.find(".dj-stickylogo").css("display", "none"), t.css({
                    position: "",
                    top: "",
                    height: "",
                    left: "",
                    width: "",
                    display: "none"
                }), e.css({
                    display: "none",
                    "min-width": ""
                }), s.find(".dj-up > .dj-subwrap").css({
                    "max-height": "",
                    "overflow-y": ""
                }), o.sticky = !1), !o.sticky && a <= n) {
                t.css({
                    position: "fixed",
                    top: parseInt(o.options.offset),
                    left: 0,
                    width: "100%",
                    display: "block"
                }), e.css({
                    "min-width": s.outerWidth(!0),
                    display: ""
                });
                var u = 0,
                    r = t.find(".dj-stickylogo");
                r.length && (r.css("display", ""), r.hasClass("dj-align-center") && (u = r.outerHeight(!0), console.log(u))), s.css({
                    position: "fixed",
                    top: parseInt(o.options.offset) + u,
                    background: "transparent",
                    height: "auto"
                }), s.addClass("dj-megamenu-fixed"), s.css("width", e.width() ? e.width() + 1 : "auto"), e.css("height", s.outerHeight()), t.css("height", u + s.outerHeight());
                var l = c(window).height() - parseInt(o.options.offset) - t.height();
                s.find(".dj-up > .dj-subwrap").each(function() {
                    c(this).find(".dj-subwrap").length || c(this).css({
                        "max-height": l,
                        "overflow-y": "auto"
                    })
                }), o.sticky = !0
            }
        }
    };
    var o = function(t, s, e, i) {
        this.options = {}, this.init(t, s, e, i)
    };
    o.prototype.init = function(t, s, e, i) {
        var o = this;
        jQuery.extend(o.options, i), o.menu = t, o.level = s, o.parent = e, o.timer = null, o.blurTimer = null, o.sub = o.menu.find("> .dj-subwrap").first(), o.menu.find(".dj-submenu > li, .dj-subtree > li").length || (o.sub.remove(), o.menu.removeClass("parent"), o.menu.find("span.dj-drop").removeClass("dj-drop"), o.menu.find("i.arrow").remove());
        var n = "mouseenter";
        if (o.options.touch || "click_all" == o.options.event) n = "click_all" == o.options.event ? "click" : n, (a = o.menu.find("> a").first()).length && (o.menu.hasClass("separator") && a.css("cursor", "pointer"), a.on("touchend click", function(t) {
            o.sub.length && !o.menu.hasClass("hover") && (t.preventDefault(), "touchend" == t.type && o.menu.trigger("click"))
        }));
        else if ("click" == o.options.event && o.menu.hasClass("separator")) {
            var a;
            (a = o.menu.find("> a").first()).length && a.css("cursor", "pointer"), n = "click"
        }(o.options.touch && (o.menu.on("click", o.showSub.bind(o)), c(document).on("touchstart", function() {
            o.menu.hasClass("hover") && o.menu.trigger("mouseleave")
        })), o.menu.on(n, o.showSub.bind(o)), o.menu.on("mouseleave", function(t) {
            c(t.target).is("input") || o.hideSub()
        }), 1 == o.options.wcag) && ((a = o.menu.find("> a").first()).on("focus", o.showSub.bind(o)), a.on("blur", function() {
            o.blurTimer = setTimeout(function() {
                if (!o.options.menu.find(":focus").length) {
                    for (var t = o; 0 < t.level;) t.hideSub(), t = t.parent;
                    t.hideSub()
                }
            }, 1e3)
        }), a.on("keydown", function(t) {
            o.focusNearest(t)
        }), o.options.menu.on("click", function() {
            clearTimeout(o.blurTimer)
        }));
        o.sub.length && (o.kids = [], o.initKids())
    }, o.prototype.focusNearest = function(t) {
        var s = this,
            i = t.which,
            o = s.menu.offset(),
            n = {
                x: 1024,
                y: 1024
            },
            a = null,
            e = function(t) {
                if (t.menu && t.menu.find("> a").length) {
                    var s = t.menu.offset(),
                        e = {
                            x: Math.abs(s.top - o.top),
                            y: Math.abs(s.left - o.left)
                        };
                    37 == i && s.left < o.left || 39 == i && s.left > o.left ? (e.x < n.x || e.x == n.x && e.y < n.y) && (n = e, a = t) : (38 == i && s.top < o.top || 40 == i && s.top > o.top) && (e.y < n.y || e.y == n.y && e.x < n.x) && (n = e, a = t)
                }
            };
        c.each(s.parent.kids, function(t, s) {
            e(s)
        }), a || (e(s.parent), s.sub.length && c.each(s.kids, function(t, s) {
            e(s)
        })), a && (t.preventDefault(), t.stopPropagation(), a.menu.find("> a").first().focus())
    }, o.prototype.showSub = function() {
        var t = this;
        clearTimeout(t.timer), t.menu.hasClass("hover") && !t.sub.hasClass(t.options.animOut) || (t.sub.length && t.sub.css("display", "none"), t.timer = setTimeout(function() {
            clearTimeout(t.animTimer), t.menu.addClass("hover"), t.hideOther(), t.sub.length && (t.sub.css("display", ""), t.sub.removeClass(t.options.animOut), t.checkDir(), t.sub.addClass(t.options.animIn), t.sub.find(".modules-wrap").length && c(window).trigger("resize"))
        }, t.options.openDelay))
    }, o.prototype.hideSub = function() {
        var t = this;
        clearTimeout(t.timer), t.sub.length ? t.timer = setTimeout(function() {
            t.menu.is(":hover") || (t.sub.removeClass(t.options.animIn), t.sub.addClass(t.options.animOut), t.animTimer = setTimeout(function() {
                t.menu.removeClass("hover")
            }, t.options.duration))
        }, t.options.closeDelay) : t.menu.removeClass("hover")
    }, o.prototype.checkDir = function() {
        var t = this;
        if (!t.menu.hasClass("fullsub")) {
            t.sub.css("left", ""), t.sub.css("right", ""), t.sub.css("margin-left", ""), t.sub.css("margin-right", "");
            var s = t.sub.offset(),
                e = t.options.wrap.offset();
            if ("ltr" == t.options.direction)(0 < (i = s.left + t.sub.outerWidth() - t.options.wrap.outerWidth() - e.left) || t.sub.hasClass("open-left")) && (t.level ? (t.sub.css("right", t.menu.outerWidth()), t.sub.css("left", "auto")) : t.sub.hasClass("open-left") ? (t.sub.css("right", t.sub.css("left")), t.sub.css("left", "auto")) : t.sub.css("margin-left", -i));
            else if ("rtl" == t.options.direction) {
                var i;
                ((i = s.left - e.left) < 0 || t.sub.hasClass("open-right")) && (t.level ? (t.sub.css("left", t.menu.outerWidth()), t.sub.css("right", "auto")) : t.sub.hasClass("open-right") ? (t.sub.css("left", t.sub.css("right")), t.sub.css("right", "auto")) : t.sub.css("margin-right", i))
            }
        }
    }, o.prototype.initKids = function() {
        var e = this;
        e.sub.find("> .dj-subwrap-in > .dj-subcol > ul.dj-submenu > li").each(function(t) {
            var s = c(this);
            e.kids[t] = new o(s, e.level + 1, e, e.options)
        })
    }, o.prototype.hideOther = function() {
        var e = this;
        c.each(e.parent.kids, function(t, s) {
            s.menu.hasClass("hover") && s != e && (s.sub.length ? (s.hideOtherSub(), s.sub.removeClass(s.options.animIn), s.sub.addClass(s.options.animOut), s.animTimer = setTimeout(function() {
                s.menu.removeClass("hover")
            }, e.options.duration)) : s.menu.removeClass("hover"))
        })
    }, o.prototype.hideOtherSub = function() {
        c.each(this.kids, function(t, s) {
            s.sub.length && (s.hideOtherSub(), s.sub.removeClass(s.options.animIn), s.sub.removeClass(s.options.animOut)), s.menu.removeClass("hover")
        })
    }, c(document).ready(function() {
        c(".dj-megamenu[data-options]").each(function() {
            var t = c(this);
            t.find(".dj-hideitem").remove(), t.data();
            var s = t.data("options");
            t.removeAttr("data-options"), t.find(".modules-wrap ul.nav li.current").each(function() {
                c(this).parents("ul.dj-submenu > li, li.dj-up").each(function() {
                    c(this).addClass("active"), c(this).find("> a").addClass("active")
                })
            }), new e(t, s)
        })
    })
}(jQuery);